-- Plot precip accuracy

-- Get the days where it was predicted that it might rain.