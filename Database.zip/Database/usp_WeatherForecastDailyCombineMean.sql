create procedure `usp_WeatherForecastDailyCombine`
(
    in _BeginDate datetime,
    in _EndDate datetime,
    in _Location varchar(100),
    in _ServiceName varchar(100)
    in _Method varchar(100)
)
begin
    declare _ForecastDataResults table
    (
        PredictionTime datetime,
        TemperatureMax float,
        TemperatureAvg float,
        TemperatureMin float,
        Wind float,
        WindBearing float,
        Humidity float,
        PrecipChance float
    )
    
    insert into _ForecastDataResults
    select date(wfd.PredictionTime) as PredictionTime, 
           wfd.TemperatureMax, wfd.TemperatureMin,
           wfd.Wind, wfd.WindBearing,
           wfd.Humidity, wfd.PrecipChance
    from tb_weatherforecastdaily as wfd -- getmode
    where ((_BeginDate is null) or (wfd.PredictionTime >= _BeginDate)) and
          ((_EndDate is null) or (wfd.PredictionTime <= _EndDate)) and
          wfd.Location = _Location and wfd.ServiceName = _ServiceName
    
    if (_Method = 'mean') then
    begin
        select PredictionTime, avg(*)
        from _ForecastDataResults
        group by PredictionTime
    end; end if;
end;
