create procedure `usp_WeatherForecastDailyCombineMean`
(
    in _BeginDate datetime,
    in _EndDate datetime,
    in _Location varchar(100),
    in _ServiceName varchar(100)
)
begin
    

    
end;
